This zip file intentionally is missing the required contents, so an error is thrown when importing
